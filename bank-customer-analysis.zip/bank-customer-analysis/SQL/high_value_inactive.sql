SELECT name, savings_balance, last_transaction_date
FROM customers
WHERE value_segment = 'High Value'
  AND last_transaction_date < CURDATE() - INTERVAL 60 DAY;
