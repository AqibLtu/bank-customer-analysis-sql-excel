create database Bank;

USE bank;

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(50),
    last_transaction_date DATE,
    activity_segment VARCHAR(20),
    savings_balance DECIMAL(10, 2),
    value_segment VARCHAR(20),
    total_products INT,
    product_segment VARCHAR(30)
);

INSERT INTO customers VALUES
(1, 'Alice', '2024-02-11', 'Active', 5200.00, 'Mid Value', 2, 'Multi-Product'),
(2, 'Bob', '2024-01-10', 'Active', 13000.50, 'Mid Value', 2, 'Multi-Product'),
(3, 'Clara', '2024-03-21', 'Active', 800.00, 'Low Value', 0, 'No Products'),
(4, 'David', '2024-04-03', 'Active', 27000.00, 'High Value', 3, 'Power User'),
(5, 'Eva', '2024-05-01', 'Active', 1500.00, 'Low Value', 1, 'Single Product');