SELECT value_segment, COUNT(*) AS total_customers
FROM customers
GROUP BY value_segment;
