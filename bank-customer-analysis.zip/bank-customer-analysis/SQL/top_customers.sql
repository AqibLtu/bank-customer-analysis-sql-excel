SELECT name, savings_balance
FROM customers
ORDER BY savings_balance DESC
LIMIT 5;
